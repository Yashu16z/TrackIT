package com.example.trackit;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.trackit.adapter.TransactionAdapter;
import com.example.trackit.data.Transaction;
import com.example.trackit.viewmodel.TransactionViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TransactionViewModel viewModel;
    private TransactionAdapter adapter;
    private TextView tvTotalBalance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvTotalBalance = findViewById(R.id.tv_total_balance);
        RecyclerView recyclerView = findViewById(R.id.rv_transactions);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TransactionAdapter();
        recyclerView.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(TransactionViewModel.class);
        viewModel.getAllTransactions().observe(this, transactions -> {
            if (transactions != null) {
                adapter.submitList(transactions);
                updateBalance(transactions);
            }
        });

        FloatingActionButton fab = findViewById(R.id.fab_add);
        fab.setOnClickListener(v -> {
            AddTransactionBottomSheet bottomSheet = new AddTransactionBottomSheet();
            bottomSheet.show(getSupportFragmentManager(), "AddTransaction");
        });

        // Swipe to delete
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                Transaction transaction = adapter.getTransactionAt(viewHolder.getBindingAdapterPosition());
                viewModel.delete(transaction);
            }
        }).attachToRecyclerView(recyclerView);
    }

    private void updateBalance(List<Transaction> transactions) {
        double balance = 0;
        for (Transaction t : transactions) {
            balance += t.getAmount();
        }
        tvTotalBalance.setText(String.format(Locale.getDefault(), "$%.2f", balance));
    }
}
